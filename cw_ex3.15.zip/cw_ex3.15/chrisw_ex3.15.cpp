#include <iostream>
#include "date.h"

using namespace std;

int main ()
{
	Date theDate(22, 21, 2015);

	theDate.displayDate();

	return 0;
}